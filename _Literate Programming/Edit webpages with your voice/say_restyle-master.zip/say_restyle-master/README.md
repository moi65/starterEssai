# Edit webpages with your voice

Include `say_restyle.js` on a page and you'll be able to edit the page by issuing voice commands.

Browsers that support the web speech API: Chrome, Safari, Opera.